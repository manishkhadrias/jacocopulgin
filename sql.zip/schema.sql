CREATE SCHEMA posdb;

drop table posdb.dbo.position_apv if exists;

CREATE TABLE posdb.dbo.position_apv
(
    id BIGINT NOT NULL AUTO_INCREMENT,
    start_date DATETIME NOT NULL,
    stop_date DATETIME NOT NULL,
    fund INT NOT NULL,
    cusip char(9),
    PRIMARY KEY(id)
);

CREATE SCHEMA portdb;

drop table portdb.dbo.port_group if exists;

CREATE TABLE portdb.dbo.port_group
(
    portfolio_group char(10) NOT NULL,
    portfolio_name char(10) NOT NULL,
    portfolio_code INT NOT NULL,
    PRIMARY KEY(portfolio_group,portfolio_name)
);