package com.khadrias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JacocoPulginApplication {

	public static void main(String[] args) {
		SpringApplication.run(JacocoPulginApplication.class, args);
	}

}
