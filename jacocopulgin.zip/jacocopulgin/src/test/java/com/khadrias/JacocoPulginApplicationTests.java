package com.khadrias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JacocoPulginApplicationTests {

	@Test
	void contextLoads() {
	}

}
