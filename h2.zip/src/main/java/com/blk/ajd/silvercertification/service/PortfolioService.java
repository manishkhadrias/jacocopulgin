/**
 * 
 */
package com.blk.ajd.silvercertification.service;

import javax.validation.Valid;

import com.blk.ajd.silvercertification.api.request.PortfolioRequest;

/**
 * @author mkhadria
 *
 */
public interface PortfolioService {

	public String findOpenPositionProtfolioCusipsOfPreviousDay(
			@Valid PortfolioRequest portfolioRequest);

}
