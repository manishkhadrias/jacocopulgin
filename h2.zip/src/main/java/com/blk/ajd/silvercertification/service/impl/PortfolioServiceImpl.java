/**
 * 
 */
package com.blk.ajd.silvercertification.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blk.ajd.silvercertification.api.model.Portfolio;
import com.blk.ajd.silvercertification.api.request.PortfolioRequest;
import com.blk.ajd.silvercertification.repository.PortfolioRepository;
import com.blk.ajd.silvercertification.repository.PositionRepository;
import com.blk.ajd.silvercertification.service.AladdinCalendarService;
import com.blk.ajd.silvercertification.service.PortfolioService;

/**
 * @author mkhadria
 *
 */
@Service
@Slf4j
public class PortfolioServiceImpl implements PortfolioService {

	private PortfolioRepository portfolioRepository;

	private PositionRepository positionRepository;

	private AladdinCalendarService aladdinCalendarService;

	@Autowired
	public PortfolioServiceImpl(PortfolioRepository portfolioRepository,
			PositionRepository positionRepository,
			AladdinCalendarService aladdinCalendarService) {
		super();
		this.portfolioRepository = portfolioRepository;
		this.positionRepository = positionRepository;
		this.aladdinCalendarService = aladdinCalendarService;
	}

	@Override
	public String findOpenPositionProtfolioCusipsOfPreviousDay(
			PortfolioRequest portfolioRequest) {
		// Pageable page = PageRequest.of(portfolioRequest.getPage(),
		// portfolioRequest.getSize());
		StringBuilder builder = new StringBuilder();
		List<Portfolio> portfolios = portfolioRepository
				.findByGroup(portfolioRequest.getGroup());
		log.info("Portfolio recieved by Portfolio group");
		for (Portfolio portfolio : portfolios) {

			LocalDate previousBusinessDate = aladdinCalendarService
					.findPreviousBusinessDay(LocalDate.of(
							portfolioRequest.getYear(),
							portfolioRequest.getMonth(),
							portfolioRequest.getDay()));
			log.info("Previous business date is fetched using Aladdin Calendar API");
			String cusips = positionRepository
					.findOpenPositionByDateAndFund(previousBusinessDate,
							portfolio.getCode()).stream()
					.collect(Collectors.joining(" , "));
			log.info("Previous business day Open Position cusips are fetched");
			if (!cusips.isEmpty()) {
				builder.append(portfolio.getId().getName() + " : ");
				builder.append(cusips);
				builder.append(" | ");
			}
		}

		if (builder.length() > 0) {
			return builder.substring(0, builder.length() - 2);
		} else {
			return "";
		}

	}
}
