/**
 * 
 */
package com.blk.ajd.silvercertification.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.blk.ajd.silvercertification.api.request.PortfolioRequest;
import com.blk.ajd.silvercertification.service.PermissionService;
import com.blk.ajd.silvercertification.service.PortfolioService;

/**
 * @author mkhadria
 *
 */
@RestController
public class PortfolioController {

	private PortfolioService portfolioService;

	private PermissionService permissionService;

	private String token;

	@Autowired
	public PortfolioController(PortfolioService portfolioService,
			PermissionService permissionService, @Value("${app.token}") String token) {
		super();
		this.portfolioService = portfolioService;
		this.permissionService = permissionService;
		this.token = token;
	}

	@PostMapping("/portfolios")
	public ResponseEntity<String> findOpenPositionProtfolioCusipsOfPreviousDay(
			@RequestHeader String authorization,
			@Valid @RequestBody PortfolioRequest portfolioRequest) {
		if (!authorization.equals(token))
			return new ResponseEntity<>("Token is not valid",
					HttpStatus.UNAUTHORIZED);

		if (!permissionService.isAllowed(portfolioRequest.getGroup()))
			return new ResponseEntity<>("User is not permitted",
					HttpStatus.UNAUTHORIZED);

		return new ResponseEntity<>(
				portfolioService
						.findOpenPositionProtfolioCusipsOfPreviousDay(portfolioRequest),
				HttpStatus.OK);
	}
}
