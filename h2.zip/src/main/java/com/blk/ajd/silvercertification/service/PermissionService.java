package com.blk.ajd.silvercertification.service;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;

import com.bfm.bms.BmsUtil;
import com.bfm.util.BFMPermissionsSet;

@Service
@Slf4j
public class PermissionService {

	public Boolean isAllowed(String portfolioGroup) {
		BFMPermissionsSet permissions = BFMPermissionsSet.getPermsByType(
				BmsUtil.getUser(), "VIEW");
		boolean isAllowed = permissions.checkPerm(portfolioGroup, "VIEW");
		log.info("User : " + BmsUtil.getUser() + " portfolioGroup : "
				+ portfolioGroup + " isAllowed: " + isAllowed);
		return isAllowed;
	}
}
