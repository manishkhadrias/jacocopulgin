package com.blk.ajd.silvercertification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
// @EnableJpaRepositories("com.blk.ajd.silvercertification.repository")
public class SilverCertificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SilverCertificationApplication.class, args);
	}

}
