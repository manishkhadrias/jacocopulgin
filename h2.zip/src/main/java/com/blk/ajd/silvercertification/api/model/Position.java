/**
 * 
 */
package com.blk.ajd.silvercertification.api.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author mkhadria
 *
 */
@Data
@Entity
@Table(name = "position_apv")
@AllArgsConstructor
@NoArgsConstructor
public class Position {

	@Id
	private long id;
	@Column(name = "start_date")
	private LocalDate startDate;
	@Column(name = "stop_date")
	private LocalDate stopDate;
	@Column(name = "fund")
	private Integer fund;
	@Column(name = "cusip")
	private String cusip;

}
