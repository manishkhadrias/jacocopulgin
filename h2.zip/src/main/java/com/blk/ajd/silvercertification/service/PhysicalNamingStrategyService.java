package com.blk.ajd.silvercertification.service;

import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;
import org.springframework.stereotype.Service;

import com.bfm.db.hibernate.BRSNamingStrategy;

@Service
public class PhysicalNamingStrategyService implements PhysicalNamingStrategy {

	@Override
	public Identifier toPhysicalCatalogName(final Identifier identifier,
			final JdbcEnvironment jdbcEnv) {

		return identifier;
	}

	@Override
	public Identifier toPhysicalColumnName(final Identifier identifier,
			final JdbcEnvironment jdbcEnv) {

		return identifier;
	}

	@Override
	public Identifier toPhysicalSchemaName(final Identifier identifier,
			final JdbcEnvironment jdbcEnv) {

		return identifier;
	}

	@Override
	public Identifier toPhysicalSequenceName(final Identifier identifier,
			final JdbcEnvironment jdbcEnv) {

		return identifier;
	}

	@Override
	public Identifier toPhysicalTableName(final Identifier identifier,
			final JdbcEnvironment jdbcEnv) {
		return Identifier.toIdentifier(new BRSNamingStrategy()
				.tableName(identifier.toString()));
	}

}
