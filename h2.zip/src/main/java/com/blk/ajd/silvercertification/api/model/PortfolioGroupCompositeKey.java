package com.blk.ajd.silvercertification.api.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

@Data
@Embeddable
public class PortfolioGroupCompositeKey implements Serializable {

	private static final long serialVersionUID = -8504216806359147679L;

	@Column(name = "portfolio_group")
	private String group;

	@Column(name = "portfolio_name")
	private String name;

}
