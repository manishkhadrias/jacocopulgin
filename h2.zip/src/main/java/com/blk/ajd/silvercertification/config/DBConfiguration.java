package com.blk.ajd.silvercertification.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bfm.db.DBConnectDataSourceFactory;

@Configuration
// @EnableJpaRepositories
// @EnableTransactionManagement
public class DBConfiguration {
	static {
		System.setProperty("defaultWebServer", "https://dev.blackrock.com/acs");
		System.setProperty("AUTH_METHOD", "SERVER");
	}

	@Bean
	public DataSource dataSource() {
		final DBConnectDataSourceFactory.Options options = new DBConnectDataSourceFactory.Options();
		options.setApplicationName("silver-certification"); // use your app name
		options.setDefaultDatabase("portdb");
		return DBConnectDataSourceFactory.createReadServerDataSource(options);
	}

	// @Bean
	// public EntityManagerFactory entityManagerFactory() {
	//
	// HibernateJpaVendorAdapter vendorAdapter = new
	// HibernateJpaVendorAdapter();
	// vendorAdapter.setShowSql(Boolean.TRUE);
	// vendorAdapter.setDatabase(Database.SYBASE);
	//
	// LocalContainerEntityManagerFactoryBean factory = new
	// LocalContainerEntityManagerFactoryBean();
	// factory.setJpaVendorAdapter(vendorAdapter);
	// factory.setDataSource(dataSource());
	// factory.setPackagesToScan("com.blk.ajd.silvercertification");
	//
	// Properties jpaProperties = new Properties();
	// jpaProperties.setProperty("hibernate.dialect",
	// "org.hibernate.dialect.SybaseASE15Dialect");
	// jpaProperties
	// .put("hibernate.physical_naming_strategy",
	// "com.blk.ajd.silvercertification.service.PhysicalNamingStrategyService");
	// factory.setJpaProperties(jpaProperties);
	// factory.afterPropertiesSet();
	// return factory.getObject();
	// }
	//
	// @Bean
	// public PlatformTransactionManager transactionManager() {
	//
	// JpaTransactionManager txManager = new JpaTransactionManager();
	// txManager.setEntityManagerFactory(entityManagerFactory());
	// return txManager;
	// }
	// @Bean
	// public ImprovedNamingStrategy namingStrategy() {
	// return new BRSNamingStrategy();
	// }

	// @Bean
	// public PhysicalNamingStrategy physical() {
	// return (PhysicalNamingStrategy) new BRSNamingStrategy();
	// }
	//
	// @Bean
	// public ImplicitNamingStrategy implicit() {
	// return new ImplicitNamingStrategyLegacyJpaImpl();
	// }

}