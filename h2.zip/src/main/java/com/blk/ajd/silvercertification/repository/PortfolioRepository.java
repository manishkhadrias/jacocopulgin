package com.blk.ajd.silvercertification.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.blk.ajd.silvercertification.api.model.Portfolio;
import com.blk.ajd.silvercertification.api.model.PortfolioGroupCompositeKey;

/**
 * @author mkhadria
 *
 */
@Repository
public interface PortfolioRepository extends
		JpaRepository<Portfolio, PortfolioGroupCompositeKey> {

	@Query("SELECT p FROM Portfolio p WHERE p.id.group = :group ")
	Page<Portfolio> findByGroupPageable(@Param("group") String group,
			Pageable pageable);

	@Query("SELECT p FROM Portfolio p WHERE p.id.group = :group ")
	List<Portfolio> findByGroup(@Param("group") String group);

}
