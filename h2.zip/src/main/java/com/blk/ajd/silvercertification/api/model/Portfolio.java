/**
 * 
 */
package com.blk.ajd.silvercertification.api.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;

/**
 * @author mkhadria
 *
 */
@Data
@Entity
@Table(name = "port_group")
public class Portfolio {

	@EmbeddedId
	private PortfolioGroupCompositeKey id;

	@Column(name = "portfolio_code")
	private int code;
}
