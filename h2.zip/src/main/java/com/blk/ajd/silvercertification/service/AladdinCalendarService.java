package com.blk.ajd.silvercertification.service;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.blackrock.datetime.api.AladdinCalendar;
import com.blackrock.datetime.api.exceptions.AladdinCalendarNotFoundException;
import com.blackrock.datetime.api.exceptions.FailedToLoadAladdinCalendarException;

@Service
public class AladdinCalendarService {
	private static Logger logger = LoggerFactory
			.getLogger(AladdinCalendarService.class);

	public LocalDate findPreviousBusinessDay(LocalDate localDate) {
		LocalDate businessDay = null;
		try {
			AladdinCalendar calc = AladdinCalendar.get("US|IN_PAY");
			businessDay = calc.addBusinessDays(localDate, -1);
		} catch (AladdinCalendarNotFoundException
				| FailedToLoadAladdinCalendarException e) {
			logger.error(String.valueOf(e));
		}
		return businessDay;
	}

}
