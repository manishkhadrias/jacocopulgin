package com.blk.ajd.silvercertification.repository;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.blk.ajd.silvercertification.api.model.Portfolio;

/**
 * @author mkhadria
 *
 */
@DataJpaTest
@RunWith(SpringJUnit4ClassRunner.class)
public class PortfolioRepositoryTest {

	@Autowired
	private PortfolioRepository portfolioRepository;

	@Test
	public void findByGroupPageableTest() {
		Pageable page = PageRequest.of(0, 10);
		Page<Portfolio> optional = portfolioRepository.findByGroupPageable(
				"Group-A", page);
		assertEquals(1401, optional.getContent().get(0).getCode());
	}

	@Test
	public void findByGroupPageableBlankTest() {
		Pageable page = PageRequest.of(0, 10);
		Page<Portfolio> optional = portfolioRepository.findByGroupPageable(
				"AC-007", page);
		assertEquals(0, optional.getContent().size());
	}

	@Test
	public void findByGroupTest() {
		List<Portfolio> findByGroup = portfolioRepository
				.findByGroup("Group-A");
		assertEquals(1401, findByGroup.get(0).getCode());
	}

	@Test
	public void findByGroupBlankTest() {
		List<Portfolio> findByGroup = portfolioRepository.findByGroup("Blank");
		assertEquals(0, findByGroup.size());
	}
}
