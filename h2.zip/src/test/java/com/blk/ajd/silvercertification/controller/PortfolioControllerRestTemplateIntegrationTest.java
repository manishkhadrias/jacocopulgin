package com.blk.ajd.silvercertification.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.blk.ajd.silvercertification.api.request.PortfolioRequest;

/**
 * @author mkhadria
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
// @Ignore
public class PortfolioControllerRestTemplateIntegrationTest {

	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int randomServerPort;

	private String baseUrl = "http://localhost:";
	private String baseUri = "/portfolios/";

	@Value("${app.token}")
	private String token;

	private String authorization = "Authorization";

	@Test
	public void findOpenPositionProtfolioOfPreviousDayTest() {
		String uri = baseUrl + randomServerPort + baseUri;
		PortfolioRequest portfolioRequest = new PortfolioRequest();
		portfolioRequest.setDay(5);
		portfolioRequest.setMonth(11);
		portfolioRequest.setYear(2022);
		portfolioRequest.setGroup("TAAMRS");

		HttpHeaders headers = new HttpHeaders();
		headers.add(authorization, token);

		HttpEntity<PortfolioRequest> request = new HttpEntity<>(
				portfolioRequest, headers);

		ResponseEntity<String> result = this.restTemplate.postForEntity(uri,
				request, String.class);

		// Verify request succeed
		Assert.assertEquals(200, result.getStatusCodeValue());
		Assert.assertTrue(!result.getBody().isEmpty());

	}

	@Test
	public void findOpenPositionNoProtfolioOfPreviousDayTest() {
		String uri = baseUrl + randomServerPort + baseUri;
		PortfolioRequest portfolioRequest = new PortfolioRequest();
		portfolioRequest.setDay(5);
		portfolioRequest.setMonth(11);
		portfolioRequest.setYear(2022);
		portfolioRequest.setGroup("AC-007");

		HttpHeaders headers = new HttpHeaders();
		headers.add(authorization, token);

		HttpEntity<PortfolioRequest> request = new HttpEntity<>(
				portfolioRequest, headers);

		ResponseEntity<String> response = this.restTemplate.postForEntity(uri,
				request, String.class);

		// Verify request succeed
		Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
		Assert.assertEquals(null, response.getBody());
	}

}
