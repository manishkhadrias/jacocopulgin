package com.blk.ajd.silvercertification.service;

import static org.mockito.ArgumentMatchers.any;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.blk.ajd.silvercertification.api.model.Portfolio;
import com.blk.ajd.silvercertification.api.model.PortfolioGroupCompositeKey;
import com.blk.ajd.silvercertification.api.request.PortfolioRequest;
import com.blk.ajd.silvercertification.repository.PortfolioRepository;
import com.blk.ajd.silvercertification.repository.PositionRepository;
import com.blk.ajd.silvercertification.service.impl.PortfolioServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class PortfolioServiceTest {

	@Mock
	private PortfolioRepository portfolioRepository;

	@Mock
	private PositionRepository positionRepository;

	@Mock
	private AladdinCalendarService aladdinCalendarService;

	@InjectMocks
	private PortfolioServiceImpl portfolioService;

	private List<Portfolio> portfolios;
	LocalDate previousBusinessDate = LocalDate.of(2022, 5, 24);

	@Before
	public void setUp() {

		portfolios = new ArrayList<>();
		Portfolio portfolio = new Portfolio();
		portfolio.setCode(1401);
		PortfolioGroupCompositeKey portfolioGroupCompositeKey = new PortfolioGroupCompositeKey();
		portfolioGroupCompositeKey.setGroup("Group-A");
		portfolioGroupCompositeKey.setName("AC-001");
		portfolio.setId(portfolioGroupCompositeKey);
		portfolios.add(portfolio);

	}

	@Test
	public void findOpenPositionProtfolioCusipsOfPreviousDayTest() {
		Mockito.when(portfolioRepository.findByGroup(any())).thenReturn(
				portfolios);
		Mockito.when(
				positionRepository.findOpenPositionByDateAndFund(
						previousBusinessDate, 1401)).thenReturn(
				Arrays.asList("31298WTP0", "31298WTP1"));
		Mockito.when(aladdinCalendarService.findPreviousBusinessDay(any()))
				.thenReturn(previousBusinessDate);
		PortfolioRequest portfolioRequest = new PortfolioRequest();
		portfolioRequest.setDay(25);
		portfolioRequest.setMonth(5);
		portfolioRequest.setYear(2022);
		portfolioRequest.setGroup("Group-A");

		Assert.assertEquals("AC-001 : 31298WTP0 , 31298WTP1 ", portfolioService
				.findOpenPositionProtfolioCusipsOfPreviousDay(portfolioRequest));

	}
}