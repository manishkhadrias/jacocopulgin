package com.blk.ajd.silvercertification.repository;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.stream.Collectors;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author mkhadria
 *
 */
@RunWith(SpringRunner.class)
@DataJpaTest
public class PositionRepositoryTest {

	@Autowired
	private PositionRepository positionRepository;

	@Test
	public void findOpenPositionByDateAndFundPageableTest() {
		Pageable page = PageRequest.of(0, 10);
		assertEquals(
				"31298WTP0 , 31298WTP1",
				positionRepository
						.findOpenPositionByDateAndFundPageable(
								LocalDate.of(2022, 5, 13), 1401, page)
						.getContent().stream()
						.collect(Collectors.joining(" , ")));
	}

	@Test
	public void findOpenPositionByDateAndFundPageableBlankTest() {
		Pageable page = PageRequest.of(0, 10);
		assertEquals(
				0,
				positionRepository
						.findOpenPositionByDateAndFundPageable(
								LocalDate.of(2020, 5, 13), 1401, page)
						.getContent().size());
	}

	@Test
	public void findOpenPositionByDateAndFundTest() {
		assertEquals("31298WTP0 , 31298WTP1", positionRepository
				.findOpenPositionByDateAndFund(LocalDate.of(2022, 5, 13), 1401)
				.stream().collect(Collectors.joining(" , ")));
	}

	@Test
	public void findOpenPositionByDateAndFundBlankTest() {
		assertEquals(
				0,
				positionRepository.findOpenPositionByDateAndFund(
						LocalDate.of(2020, 5, 13), 1401).size());
	}

}
