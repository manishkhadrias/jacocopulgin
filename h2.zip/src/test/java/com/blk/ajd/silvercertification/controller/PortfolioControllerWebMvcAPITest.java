package com.blk.ajd.silvercertification.controller;

import static org.mockito.ArgumentMatchers.any;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.blk.ajd.silvercertification.service.PermissionService;
import com.blk.ajd.silvercertification.service.PortfolioService;

/**
 * @author mkhadria
 *
 */
@RunWith(SpringRunner.class)
@WebMvcTest(PortfolioController.class)
public class PortfolioControllerWebMvcAPITest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	private PortfolioService portfolioService;

	@MockBean
	private PermissionService permissionService;

	private final String URI = "/portfolios";

	@Value("${app.token}")
	private String token;

	@Test
	public void findOpenPositionProtfolioCusipsOfPreviousDayTest()
			throws Exception {

		Mockito.when(permissionService.isAllowed(any())).thenReturn(true);
		Mockito.when(
				portfolioService
						.findOpenPositionProtfolioCusipsOfPreviousDay(any()))
				.thenReturn("AC-005 : 31298WTP8 ");
		mvc.perform(
				MockMvcRequestBuilders
						.post(URI)
						.content(
								"{\"group\":\"TAAMRS\",\"year\":2022,\"month\":5,\"day\":9,\"page\":0,\"size\":10}")
						.header("Authorization", token)
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(
						MockMvcResultMatchers.content().string(
								"AC-005 : 31298WTP8 "));
	}

	@Test
	public void findOpenPositionProtfolioCusipsOfPreviousDayUnauthorizedTest()
			throws Exception {
		Mockito.when(permissionService.isAllowed(any())).thenReturn(true);
		Mockito.when(
				portfolioService
						.findOpenPositionProtfolioCusipsOfPreviousDay(any()))
				.thenReturn("");
		mvc.perform(
				MockMvcRequestBuilders
						.post(URI)
						.content(
								"{\"group\":\"TAAMRS\",\"year\":2022,\"month\":5,\"day\":9,\"page\":0,\"size\":10}")
						.header("Authorization", "Bearer b")
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON)).andExpect(
				MockMvcResultMatchers.status().isUnauthorized());

	}

	@Test
	public void findOpenPositionProtfolioCusipsOfPreviousDayBadRequestTest()
			throws Exception {
		Mockito.when(permissionService.isAllowed(any())).thenReturn(true);
		Mockito.when(
				portfolioService
						.findOpenPositionProtfolioCusipsOfPreviousDay(any()))
				.thenReturn("");
		mvc.perform(
				MockMvcRequestBuilders.post(URI).content("")
						.contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON)).andExpect(
				MockMvcResultMatchers.status().isBadRequest());
	}
}
