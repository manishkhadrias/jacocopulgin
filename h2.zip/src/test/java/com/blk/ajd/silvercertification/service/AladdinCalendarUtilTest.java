package com.blk.ajd.silvercertification.service;

import static org.junit.Assert.assertTrue;

import java.time.LocalDate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AladdinCalendarUtilTest {

	@InjectMocks
	private AladdinCalendarService aladdinCalendarService;

	@Test
	public void findPreviousBusinessDayTest() {

		assertTrue(LocalDate.of(2022, 5, 11).equals(
				aladdinCalendarService.findPreviousBusinessDay(LocalDate.of(
						2022, 5, 12))));
	}

}
