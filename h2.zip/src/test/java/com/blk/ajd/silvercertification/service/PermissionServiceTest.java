package com.blk.ajd.silvercertification.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PermissionServiceTest {

	@InjectMocks
	private PermissionService permission;

	@Test
	public void isAllowedTest() {
		PermissionService perm = new PermissionService();
		Assert.assertTrue(perm.isAllowed("TAAMRS"));
	}
}