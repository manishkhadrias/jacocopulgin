# Introduction 
Building on top of your AJDC Bronze project, your program will:

Connect to the database

Return a list of all distinct cusips for which there is an open position on the prior business date in a specified portfolio group. 
The portfolio group will be passed in as an argument to the program.

Program output has correct format:
Format: {portfolio1's name} : {distinct cusips for portfolio1} | {portfolio2's name} : {distinct cusips for portfolio2}
Example: ABCDEDG : 000307208 , 000307123 | QWERTYU : 000307109

**To Run VM arguments**

```
-DdefaultWebServer=https://dev.blackrock.com/
-DAUTH_METHOD=SERVER
```

**To verify unit test case and Jacoco reports for code coverage**

```
mvn clean verify -DdefaultWebServer=https://dev.blackrock.com/
```

#API

```
Method: POST
URI: /portfolios
Header : Authorization : bWFuaXNoLmtoYWRyaWFAYmxhY2tyb2NrLmNvbQ==
Request : {
    "group": "TAAMRS",
    "year": 2022,
    "month": 5,
    "day": 9,
    "page":0,
    "size": 10
}

Response : 529Y2039   : BRT5LD2C8 , B7A16QWX0 , B7A16QWW2 , B7A16QX27 , BRTF00ZD9 , BRTF00ZB3 , BRTF00ZF4 | EMXCHA     : BRW1F4370 , BRTTBE9P9 , BRSN9XAU1 , B7A16LZV2 , B7A16M071 , B7A16M063 , B7A16LZL4 , BRWGU2C17 , B7A16LZW0 , B7A16LYQ4 , B7A16LYZ4 , BRWGU2CG4 , B7A16M0F3 , B7A16M2H7 , B7A16M337 , B7A16M0E6 , BRSN9X784 , BRWGU2C33 , BRWGU2BV2 , B7A16M0G1 , B7A16LZG5 , B7A16M055 | LCSMN65    : B7A16M4F9 , B7A16M3Y9 , BRSB2AGG9 , B7A16M0T3 , BRSBMNFL9 , 999258AB2 | R25GROWF   : BRWYQ9C83 , 999258AB2 | SMSLC65    : B7A16M4F9 , BRSB2AGG9 , B7A16M3Y9 , BRSBMNFL9 , B7A16M0T3 , 999258AB2  
```