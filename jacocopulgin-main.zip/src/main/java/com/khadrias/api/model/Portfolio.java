/**
 * 
 */
package com.khadrias.api.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author mkhadria
 *
 */
@Data
@AllArgsConstructor
public class Portfolio {

	private String name;
	private int code;
}